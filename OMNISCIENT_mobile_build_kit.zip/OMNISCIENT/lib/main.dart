import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const OmniscientApp());

class OmniscientApp extends StatefulWidget {
  const OmniscientApp({super.key});
  @override
  State<OmniscientApp> createState() => _OmniscientAppState();
}

class _OmniscientAppState extends State<OmniscientApp> {
  ThemeMode _themeMode = ThemeMode.system;
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'OMNISCIENT',
    debugShowCheckedModeBanner: false,
    themeMode: _themeMode,
    theme: ThemeData(colorSchemeSeed: const Color(0xFF315D9B), brightness: Brightness.light, useMaterial3: true),
    darkTheme: ThemeData(colorSchemeSeed: const Color(0xFF8DB7F0), brightness: Brightness.dark, useMaterial3: true),
    home: HomePage(onThemeChanged: (v) => setState(() => _themeMode = v)),
  );
}

class Subject {
  final String title, subtitle, icon;
  const Subject(this.title, this.subtitle, this.icon);
}

const subjects = [
  Subject('Математика', 'От арифметики до современной математики', '∑'),
  Subject('Физика', 'От механики до квантовой теории поля', '⚛'),
  Subject('Химия', 'От строения атома до материаловедения', '⚗'),
  Subject('Биология', 'От молекул до экосистем', '⌬'),
  Subject('Информатика', 'Алгоритмы, ИИ и вычислительные системы', '⌘'),
  Subject('Астрономия', 'Планеты, звёзды и космология', '✦'),
  Subject('Медицина', 'Фундаментальные и клинические науки', '✚'),
  Subject('Науки о Земле', 'Геология, климат и океанология', '◈'),
];

class HomePage extends StatefulWidget {
  final ValueChanged<ThemeMode> onThemeChanged;
  const HomePage({super.key, required this.onThemeChanged});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _tab = 0;
  String _query = '';
  final Set<String> _completed = {};
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadProgress();
  }

  Future<void> _loadProgress() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _completed.addAll(prefs.getStringList('completed') ?? []);
      _loading = false;
    });
  }

  Future<void> _toggle(String item) async {
    setState(() => _completed.contains(item) ? _completed.remove(item) : _completed.add(item));
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('completed', _completed.toList());
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      _catalog(),
      _simplePage('Карта знаний', 'Связи между понятиями и научными дисциплинами будут доступны в следующих версиях.', Icons.account_tree_outlined),
      _simplePage('AI-преподаватель', 'Подключение языковой модели ещё не выполнено. Приложение не имитирует ответы несуществующего ИИ.', Icons.smart_toy_outlined),
      _simplePage('Библиотека', 'Здесь появятся публикации, учебники и открытые научные данные с указанием первоисточников.', Icons.local_library_outlined),
      _simplePage('Профиль и прогресс', _loading ? 'Загрузка…' : 'Завершено разделов: ${_completed.length}', Icons.person_outline),
    ];
    return LayoutBuilder(builder: (context, constraints) {
      final wide = constraints.maxWidth >= 760;
      return Scaffold(
        appBar: AppBar(
          title: const Text('OMNISCIENT', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: 1.2)),
          actions: [
            PopupMenuButton<ThemeMode>(
              tooltip: 'Тема оформления',
              icon: const Icon(Icons.contrast),
              onSelected: widget.onThemeChanged,
              itemBuilder: (_) => const [
                PopupMenuItem(value: ThemeMode.system, child: Text('Как на устройстве')),
                PopupMenuItem(value: ThemeMode.light, child: Text('Светлая')),
                PopupMenuItem(value: ThemeMode.dark, child: Text('Тёмная')),
              ],
            ),
            const SizedBox(width: 8),
          ],
        ),
        body: Row(children: [
          if (wide) NavigationRail(
            selectedIndex: _tab,
            onDestinationSelected: (v) => setState(() => _tab = v),
            labelType: NavigationRailLabelType.all,
            destinations: const [
              NavigationRailDestination(icon: Icon(Icons.explore_outlined), label: Text('Науки')),
              NavigationRailDestination(icon: Icon(Icons.account_tree_outlined), label: Text('Карта')),
              NavigationRailDestination(icon: Icon(Icons.smart_toy_outlined), label: Text('Преподаватель')),
              NavigationRailDestination(icon: Icon(Icons.menu_book_outlined), label: Text('Библиотека')),
              NavigationRailDestination(icon: Icon(Icons.person_outline), label: Text('Профиль')),
            ],
          ),
          Expanded(child: pages[_tab]),
        ]),
        bottomNavigationBar: wide ? null : NavigationBar(
          selectedIndex: _tab,
          onDestinationSelected: (v) => setState(() => _tab = v),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.explore_outlined), label: 'Науки'),
            NavigationDestination(icon: Icon(Icons.account_tree_outlined), label: 'Карта'),
            NavigationDestination(icon: Icon(Icons.smart_toy_outlined), label: 'ИИ'),
            NavigationDestination(icon: Icon(Icons.menu_book_outlined), label: 'Библиотека'),
            NavigationDestination(icon: Icon(Icons.person_outline), label: 'Профиль'),
          ],
        ),
      );
    });
  }

  Widget _catalog() {
    final filtered = subjects.where((s) => ('${s.title} ${s.subtitle}').toLowerCase().contains(_query.toLowerCase())).toList();
    return ListView(padding: const EdgeInsets.all(20), children: [
      Text('Изучай устройство мира', style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      Text('Единая карта знаний — от первых принципов до передовых исследований.', style: Theme.of(context).textTheme.bodyLarge),
      const SizedBox(height: 20),
      TextField(
        decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Найти дисциплину или тему', border: OutlineInputBorder()),
        onChanged: (v) => setState(() => _query = v),
      ),
      const SizedBox(height: 16),
      for (final s in filtered)
        Card(
          child: ListTile(
            leading: CircleAvatar(child: Text(s.icon, style: const TextStyle(fontSize: 22))),
            title: Text(s.title, style: const TextStyle(fontWeight: FontWeight.w600)),
            subtitle: Text(s.subtitle),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => SubjectPage(subject: s, completed: _completed, onToggle: _toggle))),
          ),
        ),
      const SizedBox(height: 12),
      const Text('Демонстрационная версия: содержание разделов и научная библиотека будут постепенно наполняться проверенными источниками.', style: TextStyle(fontStyle: FontStyle.italic)),
    ]);
  }

  Widget _simplePage(String title, String description, IconData icon) => Center(
    child: ConstrainedBox(
      constraints: const BoxConstraints(maxWidth: 620),
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(icon, size: 64, color: Theme.of(context).colorScheme.primary),
          const SizedBox(height: 20),
          Text(title, style: Theme.of(context).textTheme.headlineMedium, textAlign: TextAlign.center),
          const SizedBox(height: 12),
          Text(description, textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodyLarge),
        ]),
      ),
    ),
  );
}

class SubjectPage extends StatelessWidget {
  final Subject subject;
  final Set<String> completed;
  final Future<void> Function(String) onToggle;
  const SubjectPage({super.key, required this.subject, required this.completed, required this.onToggle});

  @override
  Widget build(BuildContext context) {
    final lessons = ['Введение и основные понятия', 'Фундаментальные принципы', 'Математический аппарат', 'Практические задачи', 'Современные исследования'];
    return Scaffold(
      appBar: AppBar(title: Text(subject.title)),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        Text(subject.subtitle, style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 16),
        const Text('Учебная траектория', style: TextStyle(fontWeight: FontWeight.bold)),
        for (final lesson in lessons)
          Card(child: CheckboxListTile(
            value: completed.contains('${subject.title}:$lesson'),
            title: Text(lesson),
            subtitle: const Text('Учебный модуль — содержание будет добавлено'),
            onChanged: (_) => onToggle('${subject.title}:$lesson'),
          )),
      ]),
    );
  }
}
